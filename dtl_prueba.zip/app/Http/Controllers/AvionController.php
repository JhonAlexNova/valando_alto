<?php

namespace App\Http\Controllers;

use App\Avion;
use Illuminate\Http\Request;

class AvionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function get_aviones($id_tipo){
        $aviones = Avion::with('tipo_avion')->where('id_tipo_avion',$id_tipo)->get();

        return $aviones;
    }

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Avion  $avion
     * @return \Illuminate\Http\Response
     */
    public function show(Avion $avion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Avion  $avion
     * @return \Illuminate\Http\Response
     */
    public function edit(Avion $avion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Avion  $avion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Avion $avion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Avion  $avion
     * @return \Illuminate\Http\Response
     */
    public function destroy(Avion $avion)
    {
        //
    }
}
