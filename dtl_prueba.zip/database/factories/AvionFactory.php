<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Avion;
use Faker\Generator as Faker;

$factory->define(Avion::class, function (Faker $faker) {
    return [
        //
    ];
});
