<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Lugares;
use Faker\Generator as Faker;

$factory->define(Lugares::class, function (Faker $faker) {
    return [
        //
    ];
});
