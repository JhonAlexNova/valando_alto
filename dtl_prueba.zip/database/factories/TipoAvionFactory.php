<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Tipo_Avion;
use Faker\Generator as Faker;

$factory->define(Tipo_Avion::class, function (Faker $faker) {
    return [
        //
    ];
});
