<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Tipo_Usuario;
use Faker\Generator as Faker;

$factory->define(Tipo_Usuario::class, function (Faker $faker) {
    return [
        //
    ];
});
