<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Vuelos;
use Faker\Generator as Faker;

$factory->define(Vuelos::class, function (Faker $faker) {
    return [
        //
    ];
});
