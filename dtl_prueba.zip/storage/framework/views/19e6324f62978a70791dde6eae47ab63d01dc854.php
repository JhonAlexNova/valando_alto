

<?php $__env->startSection('content'); ?>
<div class="col-md-12 form-group">
	<a href="<?php echo e(url('app/usuarios/create')); ?>" class="btn btn-outline-success">Crear empleado</a>
</div>
<div class="col-md-12">
	<table class="table table-bordered">
		<thead>
			<th>N°</th>
			<th>Nombres</th>
			<th>Cargo</th>
		</thead>
		 <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		 	<tr>
		 		<td> <?php echo e($key); ?> </td>
		 		<td> <?php echo e($empleado->nombre); ?> </td>
		 		<td> <?php echo e($empleado->tipo_usuario->last()->rol->tipo); ?>  </td>  
		 	</tr>
		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\SERVER\xamp\htdocs\dtl_prueba\resources\views/app/usuario/index.blade.php ENDPATH**/ ?>