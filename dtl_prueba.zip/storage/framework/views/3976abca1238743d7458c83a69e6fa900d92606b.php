<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="container">
        <div class="row">
                <div class="col-md-12">
                    <?php if(Session::has('response')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(Session::get('response')); ?>   
                        </div>
                    <?php endif; ?>

                     <?php if(Session::has('error')): ?>
                        <div class="alert alert-warning" role="alert">
                            <?php echo e(Session::get('error')); ?>   
                        </div>
                    <?php endif; ?>
                </div>
                <?php $__currentLoopData = $vuelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vuelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3" style="padding: 10px">
                        <div class="card" style="width: 95%; display: block;margin: auto;">
                          <div class="card-body">
                            <p class="card-text">
                                <b>Avion: </b> <?php echo e($vuelo->avion->identificacion_avion); ?> <br>
                                <b>Piloto: </b> <?php echo e($vuelo->piloto->nombre); ?> <br>
                                <b>Copiloto: </b> <?php echo e($vuelo->copiloto->nombre); ?> <br>
                                <b>Origen: </b> <?php echo e($vuelo->origen->nombre); ?> <br>
                                <b>Origen: </b> <?php echo e($vuelo->destino->nombre); ?> <br>
                                <b>Origen: </b> <?php echo e($vuelo->precio); ?> <br>
                            </p>
                            <a href="javascript:void(0);" class="btn btn-outline-success" onclick="reservar('<?php echo e($vuelo->id); ?>')">Reservar</a>
                          </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
            </div>
    </div>
</div>


<form action="<?php echo e(route('reservacion.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="modal" id="modal_user" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-body">
            <div class="row">
                <input type="hidden" name="id_vuelo">
                <div class="col-md-6 form-group">
                    <span>Cedula</span>
                    <input type="text" name="cedula" class="form-control">
                </div>

                <div class="col-md-6 form-group">
                    <span>Nombre</span>
                    <input type="text" name="nombre" class="form-control">
                </div>
                <div class="col-md-6 form-group">
                    <span>Apellidos</span>
                    <input type="text" name="apellido" class="form-control">
                </div>
                <div class="col-md-6 form-group">
                    <span>Telefono</span>
                    <input type="text" name="telefono" class="form-control">
                </div>
                <div class="col-md-6 form-group">
                    <span>Correo</span>
                    <input type="text" name="correo" class="form-control">
                </div>

            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <button type="submit" class="btn btn-primary">Confirmar</button>
          </div>
        </div>
      </div>
    </div>
</form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\SERVER\xamp\htdocs\dtl_prueba\resources\views/welcome.blade.php ENDPATH**/ ?>