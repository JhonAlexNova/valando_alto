

<?php $__env->startSection('content'); ?>
<div class="col-md-12 form-group">
	<a href="<?php echo e(url('app/vuelos/create')); ?>" class="btn btn-outline-success">Crear vuelo</a>
</div>
<div class="col-md-12">
	<table class="table table-bordered">
		<thead>
			<th>N°</th>
			<th>Avion</th>
			<th>Piloto</th>
			<th>Copiloto</th>
			<th>Origen</th>
			<th>Destino</th>
			<th>Precio</th>
			<th>Opciones</th>
		</thead>
		<tbody>
			<?php $__currentLoopData = $vuelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vuelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td> <?php echo e($key); ?> </td>
					<td> <?php echo e($vuelo->avion->identificacion_avion); ?> </td>
					<td> <?php echo e($vuelo->piloto->nombre); ?> </td>
					<td> <?php echo e($vuelo->copiloto->nombre); ?> </td>
					<td> <?php echo e($vuelo->origen->nombre); ?> </td>
					<td> <?php echo e($vuelo->destino->nombre); ?> </td>
					<td> $<?php echo e(number_format($vuelo->precio)); ?> </td>
					<td><a href="<?php echo e(url('app/reservacion',$vuelo->id)); ?>">Ver reservaciones</a></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\SERVER\xamp\htdocs\dtl_prueba\resources\views/app/vuelo/index.blade.php ENDPATH**/ ?>