

<?php $__env->startSection('content'); ?>
<div class="col-md-12 form-group">
	<a href="<?php echo e(url('app/vuelos')); ?>" class="btn btn-outline-success">Volver</a>
</div>
<div class="col-md-12">
	<div class="">
		<?php if(Session::has('response')): ?>
			<div class="alert alert-success" role="alert">
				<?php echo e(Session::get('response')); ?>	 
			</div>
		<?php endif; ?>
		<form action="<?php echo e(route('vuelos.store')); ?>" method="post">
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="col-md-4 form-group">
					<span>Avion</span>
					<select name="id_avion" class="form-control" required>
						<option ></option>
						<?php $__currentLoopData = $aviones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $avion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($avion->id); ?>"> <?php echo e($avion->tipo_avion->tipo); ?>  <?php echo e($avion->identificacion_avion); ?> </option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>

				<div class="col-md-4 form-group">
					<span>Piloto</span>
					<select name="id_piloto" class="form-control" required>
						<option ></option>
						<?php $__currentLoopData = $pilotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $piloto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($piloto->id); ?>"> <?php echo e($piloto->nombre); ?> </option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>

				<div class="col-md-4 form-group">
					<span>Copiloto</span>
					<select name="id_copiloto" class="form-control" required>
						<option ></option>
						<?php $__currentLoopData = $copilotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $copiloto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($copiloto->id); ?>"> <?php echo e($copiloto->nombre); ?> </option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>

				<div class="col-md-4 form-group">
					<span>Origen</span>
					<select name="id_origen" class="form-control" required>
						<option ></option>
						<?php $__currentLoopData = $lugares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lugar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($lugar->id); ?>"> <?php echo e($lugar->nombre); ?> </option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>

				<div class="col-md-4 form-group">
					<span>Destino</span>
					<select name="id_destino" class="form-control" required>
						<option ></option>
						<?php $__currentLoopData = $lugares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lugar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($lugar->id); ?>"> <?php echo e($lugar->nombre); ?> </option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>

				
				<div class="col-md-4 form-group">
					<span>Precio</span>
					<input type="text" class="form-control" name="precio" required>
				</div>
				<div class="form-group col-md-12">
					<button class="btn btn-outline-primary" type="submit">Crear</button>
				</div>
			</div>
		</form>
	</div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\SERVER\xamp\htdocs\dtl_prueba\resources\views/app/vuelo/create.blade.php ENDPATH**/ ?>