

<?php $__env->startSection('content'); ?>
<div class="col-md-12 form-group">
	<a href="<?php echo e(url('app/vuelos')); ?>" class="btn btn-outline-success">Volver</a>
</div>
<div class="col-md-12">
	<div class="alert alert-info">
		<h2>Detalles del vuelo</h2>
		<ul>
			<li><b>Vuelo:</b> <?php echo e($vuelo->avion->id); ?> </li>
			<li><b>Avion:</b> <?php echo e($vuelo->avion->identificacion_avion); ?> </li>
			<li><b>piloto:</b> <?php echo e($vuelo->piloto->nombre); ?> </li>
			<li><b>copiloto:</b> <?php echo e($vuelo->piloto->nombre); ?> </li>
			<li><b>Origen:</b> <?php echo e($vuelo->origen->nombre); ?> </li>
			<li><b>Destino:</b> <?php echo e($vuelo->destino->nombre); ?> </li>
			<li><b>Precio:</b> $<?php echo e(number_format($vuelo->precio)); ?> </li>
		</ul>
	</div>
	<table class="table table-bordered">
		<thead>
			<th>N°</th>
			<th>Nombres</th>
			<th>Apellidos</th>
			<th>Cedula</th>
			<th>Telefono</th>
			<th>Correo</th>
		</thead>
		<tbody>
			<?php $__currentLoopData = $reservaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $reservacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td> <?php echo e($key); ?> </td>
					<td> <?php echo e($reservacion->cliente->nombre); ?> </td>
					<td> <?php echo e($reservacion->cliente->apellido); ?> </td>
					<td> <?php echo e($reservacion->cliente->cedula); ?> </td>
					<td> <?php echo e($reservacion->cliente->telefono); ?> </td>
					<td> <?php echo e($reservacion->cliente->correo); ?> </td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\SERVER\xamp\htdocs\dtl_prueba\resources\views/app/reservacion/index.blade.php ENDPATH**/ ?>